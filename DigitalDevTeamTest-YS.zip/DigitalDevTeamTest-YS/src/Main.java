
//import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yuktashrestha
 */
public class Main {

    public static void main(String[] args) {
        
        
        Scanner scan = new Scanner(System.in);
        //asks for user to input their restaurant location
        System.out.println("Please enter your restaurant location below.");
        String input = scan.nextLine();
       
        //asks for user to input amount of tiramisus ordered
        System.out.println("Please enter the amount of tiramisus ordered");
        int amount = scan.nextInt();

        //initialise new Controller object
        Controller cD = new Controller();
        
        for (int i = 0; i < amount; i++) {
        cD.placeOrderForLoc(input, "tiramisu");
        }
        
        //output total amount of tiramisus ordered in specific location
        System.out.println("Total amount of tiramisus ordered in " + input + ": " + amount);
        
        //output the overall eggs required for the corresponding location
        System.out.println("Overall Eggs Required: " + cD.getOverallEggsRequired());
        
        //add 10 eggs to the overall eggs required incase more eggs are required 
        //in the next month or some eggs get damaged
        int eggsAmount = cD.getOverallEggsRequired() + 10;
        
        //output amount of eggs being sent to corresponding location
        System.out.println("Amount of eggs to be sent: ");
        cD.notifyChain(input, eggsAmount);

    }
}
