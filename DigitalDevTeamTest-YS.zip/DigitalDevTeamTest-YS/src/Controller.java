
import java.util.ArrayList;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yuktashrestha
 */
public class Controller {
    
    ArrayList<Restaurant> chains;

    public Controller() {
       this.chains = new ArrayList<Restaurant>();
       chains.add(new Restaurant("Oxford Street"));
       chains.add(new Restaurant("Baker Street")); 
       chains.add(new Restaurant("Covent Garden"));
    }
    
    public int getOverallEggsRequired() {
        int overallEggsRequired = 0;
        
        for(int i = 0; i < chains.size(); i++) {
            overallEggsRequired += chains.get(i).getEggRequired();
        }
        return overallEggsRequired;
    }
    
    public void notifyChain(String chain, int eggSent) {
        for(int i = 0; i < chains.size(); i++) {
            if(chains.get(i).getLocation().equals(chain)) {
                chains.get(i).setEggsSent(eggSent);
                System.out.println(chain + " " + eggSent);
            }
        }
    }
    
    public void placeOrderForLoc(String location, String item) {
        for(int i = 0; i < chains.size(); i++) {
            if(chains.get(i).getLocation().equals(location)) {
                chains.get(i).placeOrder(item);
                //System.out.println(location + " " + item);
            }
        }
    }
    
}
