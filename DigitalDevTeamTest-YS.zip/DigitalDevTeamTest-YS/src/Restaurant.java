/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yuktashrestha
 */
public class Restaurant {

    private String location;
    private int tAmount;
    private int eggRequired;
    private int eggsSent;

    public Restaurant(String location) {
        this.location = location;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int gettAmount() {
        return tAmount;
    }

    public void settAmount(int tAmount) {
        this.tAmount = tAmount;
    }

    public int getEggRequired() {
        return eggRequired;
    }

    public void setEggRequired(int eggRequired) {
        this.eggRequired = eggRequired;
    }

    public int getEggsSent() {
        return eggsSent;
    }

    public void setEggsSent(int eggsSent) {
        this.eggsSent = eggsSent;
    }

    public void placeOrder(String s) {
        if (s.equals("tiramisu")) {
            eggRequired = eggRequired + 3;
        }
    }

}
